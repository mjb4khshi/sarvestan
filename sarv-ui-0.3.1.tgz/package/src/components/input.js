// 🌿 Sarv UI - Modern Animated Input Component
// Built with care by MJ

export default function input({ addComponents, addBase }) {
  const baseInputSelector =
    ".input, .input-border, .input-shadow, .input-underline";

  if (addBase) {
    addBase({
      // Keyframe animation for input loading spinner
      "@keyframes rotateInputLoading": {
        "0%": { transform: "rotate(0deg)" },
        "100%": { transform: "rotate(360deg)" },
      },
    });
  }

  addComponents({
    // Wrapper for label, input, icons, message and animated effects
    ".input-wrap": {
      display: "inline-flex",
      flexDirection: "column",
      position: "relative",
      alignSelf: "center",
      justifyContent: "center",
      color: "var(--color-base-content)",
      transition: "all 0.25s ease",
      backgroundColor: "transparent !important",
      border: "none !important",
      "&.input-block, &.w-full": {
        width: "100%",
      },
    },

    // Clean Label above input
    ".input-label": {
      display: "block",
      fontSize: "0.8rem",
      lineHeight: "1.15rem",
      fontWeight: "500",
      color: "var(--color-neutral)",
      marginBottom: "0.35rem",
      transition: "color 0.25s ease",
      userSelect: "none",
      ".input-wrap:focus-within > &": {
        color: "var(--input-color, var(--color-primary))",
      },
    },

    // The container that holds input + icons + animated effects
    // Features smooth center-expanding bottom accent line on focus!
    ".input-box": {
      display: "flex",
      alignItems: "center",
      justifyContent: "flex-start",
      position: "relative",
      borderRadius: "var(--radius-input, 12px)",
      width: "100%",
      backgroundColor: "transparent !important",
      border: "none !important",
      "&::after": {
        content: "''",
        position: "absolute",
        inset: "0px",
        borderRadius: "var(--radius-input, 12px)",
        border: "2px solid transparent",
        borderBottom:
          "2px solid var(--input-color, var(--color-primary)) !important",
        boxSizing: "border-box",
        pointerEvents: "none",
        clipPath: "inset(0 50% 0 50%)",
        transition: "clip-path 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
        zIndex: "4",
      },
      "&:focus-within::after": {
        clipPath: "inset(0 0% 0 0%)",
      },
    },

    // For border/underline variant: keep bottom line straight
    ".input-box:has(.input-border)::after, .input-box:has(.input-underline)::after": {
      borderRadius: "0px !important",
    },

    // ==========================================
    // Base Input (.input)
    // Pure filled square, NO 4-sided border outline!
    // Powered 100% by system design tokens
    // ==========================================
    [baseInputSelector]: {
      display: "block",
      width: "100%",
      outline: "none !important",
      WebkitAppearance: "none",
      MozAppearance: "none",
      appearance: "none",
      boxSizing: "border-box",
      fontFamily: "inherit",
      fontSize: "0.85rem",
      lineHeight: "1.25rem",
      color: "var(--color-base-content)",
      borderRadius: "var(--radius-input, 12px)",
      "--input-px": "16px",
      "--input-slide": "5px",
      padding: "8px var(--input-px)",
      paddingInlineStart: "var(--input-px)",
      border: "2px solid transparent !important", // No 4-sided border line
      backgroundColor: "var(--color-base-500)",
      transition: "all 0.25s cubic-bezier(0.4, 0, 0.2, 1)",
      "&::placeholder": {
        color: "color-mix(in oklab, var(--color-base-content) 45%, var(--color-neutral))",
        opacity: "0.85",
        transition: "color 0.25s ease, opacity 0.25s ease, padding 0.25s ease",
      },
      "&:hover": {
        backgroundColor:
          "color-mix(in oklab, var(--color-base-500) 88%, var(--color-base-content))",
        "&::placeholder": {
          color: "color-mix(in oklab, var(--color-base-content) 65%, var(--color-neutral))",
          opacity: "0.95",
        },
      },
      // Clean Autofill handling across browsers without jarring default yellow/blue backgrounds
      "&:-webkit-autofill, &:-webkit-autofill:hover, &:-webkit-autofill:focus, &:-webkit-autofill:active": {
        WebkitTextFillColor: "var(--color-base-content) !important",
        WebkitBoxShadow: "0 0 0 1000px var(--color-base-500) inset !important",
        boxShadow: "0 0 0 1000px var(--color-base-500) inset !important",
        caretColor: "var(--color-base-content)",
        transition: "background-color 5000s ease-in-out 0s",
      },
      "&:focus:-webkit-autofill, &:focus-visible:-webkit-autofill": {
        WebkitBoxShadow:
          "0 0 0 1000px color-mix(in oklab, var(--color-base-500) 88%, var(--color-base)) inset !important",
        boxShadow:
          "0 0 0 1000px color-mix(in oklab, var(--color-base-500) 88%, var(--color-base)) inset !important",
      },
      // Focus: text slide forward + center-expanding line via .input-box::after!
      "&:focus, &:focus-visible": {
        outline: "none !important",
        backgroundColor:
          "color-mix(in oklab, var(--color-base-500) 88%, var(--color-base))",
        paddingInlineStart:
          "calc(var(--input-px) + var(--input-slide)) !important", // Proportional slide forward!
        borderBottomColor:
          "var(--input-color, var(--color-primary)) !important",
        boxShadow: "none !important",
      },
      "&:disabled": {
        cursor: "not-allowed",
        opacity: "0.45",
        backgroundColor: "var(--color-base-500) !important",
        borderBottomColor: "transparent !important",
        transform: "none !important",
      },
    },

    // Suppress standalone bottom border when inside .input-box (so .input-box::after curve is used)
    ".input-box > :is(.input, .input-border, .input-shadow, .input-underline):focus":
      {
        borderBottomColor: "transparent !important",
      },

    // ==========================================
    // 1. Floating 3D Icon
    // ==========================================
    ".input-icon-left, .input-icon-right": {
      position: "absolute",
      top: "50%",
      transform: "translateY(-50%)",
      width: "36px",
      height: "36px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      borderRadius: "var(--radius-input, 12px)",
      backgroundColor: "var(--color-base-500)",
      color: "var(--color-neutral)",
      pointerEvents: "none",
      transition: "all 0.25s cubic-bezier(0.4, 0, 0.2, 1)",
      zIndex: "2",
      border: "none !important",
      "& > svg": {
        width: "1.1rem",
        height: "1.1rem",
      },
    },
    ".input-icon-left": {
      insetInlineStart: "0px",
      boxShadow: "none",
    },
    ".input-icon-right": {
      insetInlineEnd: "0px",
      boxShadow: "none",
    },

    // Padding shift when icons are present
    ".input-box:has(.input-icon-left) > :is(.input, .input-border, .input-shadow, .input-underline), .input-wrap:has(.input-icon-left) :is(.input, .input-border, .input-shadow, .input-underline), .input.input-has-icon":
      {
        paddingInlineStart: "44px !important",
      },
    ".input-box:has(.input-icon-right) > :is(.input, .input-border, .input-shadow, .input-underline), .input-wrap:has(.input-icon-right) :is(.input, .input-border, .input-shadow, .input-underline), .input.input-has-icon-right":
      {
        paddingInlineEnd: "44px !important",
      },
    ".input-box:focus-within:has(.input-icon-left) > :is(.input, .input-border, .input-shadow, .input-underline), .input-wrap:focus-within:has(.input-icon-left) :is(.input, .input-border, .input-shadow, .input-underline), .input-box:has(.input-icon-left) > :is(.input, .input-border, .input-shadow, .input-underline):focus, .input.input-has-icon:focus":
      {
        paddingInlineStart: "49px !important", // slides forward 5px with icon!
      },

    // When left icon is paired with specific sizes:
    ".input-box:has(.input-icon-left).input-xs > :is(.input, .input-border, .input-shadow, .input-underline), .input-box:has(.input-icon-left):has(.input-xs) > :is(.input, .input-border, .input-shadow, .input-underline)":
      {
        paddingInlineStart: "38px !important",
      },
    ".input-box:focus-within:has(.input-icon-left).input-xs > :is(.input, .input-border, .input-shadow, .input-underline), .input-box:focus-within:has(.input-icon-left):has(.input-xs) > :is(.input, .input-border, .input-shadow, .input-underline)":
      {
        paddingInlineStart: "42px !important",
      },
    ".input-box:has(.input-icon-left).input-sm > :is(.input, .input-border, .input-shadow, .input-underline), .input-box:has(.input-icon-left):has(.input-sm) > :is(.input, .input-border, .input-shadow, .input-underline)":
      {
        paddingInlineStart: "40px !important",
      },
    ".input-box:focus-within:has(.input-icon-left).input-sm > :is(.input, .input-border, .input-shadow, .input-underline), .input-box:focus-within:has(.input-icon-left):has(.input-sm) > :is(.input, .input-border, .input-shadow, .input-underline)":
      {
        paddingInlineStart: "45px !important",
      },
    ".input-box:has(.input-icon-left).input-lg > :is(.input, .input-border, .input-shadow, .input-underline), .input-box:has(.input-icon-left):has(.input-lg) > :is(.input, .input-border, .input-shadow, .input-underline)":
      {
        paddingInlineStart: "46px !important",
      },
    ".input-box:focus-within:has(.input-icon-left).input-lg > :is(.input, .input-border, .input-shadow, .input-underline), .input-box:focus-within:has(.input-icon-left):has(.input-lg) > :is(.input, .input-border, .input-shadow, .input-underline)":
      {
        paddingInlineStart: "52px !important",
      },
    ".input-box:has(.input-icon-left).input-xl > :is(.input, .input-border, .input-shadow, .input-underline), .input-box:has(.input-icon-left):has(.input-xl) > :is(.input, .input-border, .input-shadow, .input-underline)":
      {
        paddingInlineStart: "48px !important",
      },
    ".input-box:focus-within:has(.input-icon-left).input-xl > :is(.input, .input-border, .input-shadow, .input-underline), .input-box:focus-within:has(.input-icon-left):has(.input-xl) > :is(.input, .input-border, .input-shadow, .input-underline)":
      {
        paddingInlineStart: "55px !important",
      },

    // Signature: Icon floats out in 3D with soft clean shadow when input is focused!
    ".input-box:focus-within > .input-icon-left": {
      transform: "translate(-6px, calc(-50% - 6px))",
      backgroundColor: "var(--color-base)",
      color: "var(--input-color, var(--color-primary))",
      boxShadow:
        "0px 8px 20px -4px rgba(var(--shadow-color), 0.25), 0px 4px 8px -2px rgba(var(--shadow-color), 0.1)",
    },
    ".input-box:focus-within > .input-icon-right": {
      transform: "translate(6px, calc(-50% - 6px))",
      backgroundColor: "var(--color-base)",
      color: "var(--input-color, var(--color-primary))",
      boxShadow:
        "0px 8px 20px -4px rgba(var(--shadow-color), 0.25), 0px 4px 8px -2px rgba(var(--shadow-color), 0.1)",
    },
    // When combined with floating label: Top of square icon aligns horizontally with top of floating text!
    ".input-box:has(.input-label-placeholder):focus-within > .input-icon-left": {
      transform: "translate(-6px, -2.2rem)",
      backgroundColor: "var(--color-base)",
      color: "var(--input-color, var(--color-primary))",
      boxShadow:
        "0px 8px 20px -4px rgba(var(--shadow-color), 0.25), 0px 4px 8px -2px rgba(var(--shadow-color), 0.1)",
    },
    ".input-box:has(.input-label-placeholder):focus-within > .input-icon-right": {
      transform: "translate(6px, -2.2rem)",
      backgroundColor: "var(--color-base)",
      color: "var(--input-color, var(--color-primary))",
      boxShadow:
        "0px 8px 20px -4px rgba(var(--shadow-color), 0.25), 0px 4px 8px -2px rgba(var(--shadow-color), 0.1)",
    },
    ".input-box:has(.input-label-placeholder):has(:is(.input, .input-border, .input-shadow):not(:placeholder-shown)) > .input-icon-left, .input-box:has(.input-label-placeholder):has(:is(.input, .input-border, .input-shadow):-webkit-autofill) > .input-icon-left":
      {
        transform: "translate(0px, -2.2rem)",
        backgroundColor: "var(--color-base-500)",
        color: "var(--color-neutral)",
        boxShadow: "0px 4px 12px -2px rgba(var(--shadow-color), 0.2)",
      },
    ".input-box:has(.input-label-placeholder):has(:is(.input, .input-border, .input-shadow):not(:placeholder-shown)) > .input-icon-right, .input-box:has(.input-label-placeholder):has(:is(.input, .input-border, .input-shadow):-webkit-autofill) > .input-icon-right":
      {
        transform: "translate(0px, -2.2rem)",
        backgroundColor: "var(--color-base-500)",
        color: "var(--color-neutral)",
        boxShadow: "0px 4px 12px -2px rgba(var(--shadow-color), 0.2)",
      },

    // ==========================================
    // 2. Border Variant (.input-border)
    // Clean underline style (ONLY on input element, NEVER on wrapper or box!)
    // ==========================================
    ":is(input, textarea, select).input-border, .input-wrap.input-border :is(input, textarea, select), .input-box:has(.input-border) > :is(input, textarea, select)":
      {
        "--input-px": "4px",
        "--input-slide": "4px",
        backgroundColor: "transparent !important",
        borderRadius: "0px !important",
        border: "none !important",
        borderBottom:
          "2px solid color-mix(in oklab, var(--color-base-content) 20%, transparent) !important",
        paddingInlineStart: "var(--input-px)",
        "&:hover": {
          borderBottomColor: "var(--color-neutral) !important",
        },
        "&:focus, &:focus-visible": {
          backgroundColor: "transparent !important",
          paddingInlineStart:
            "calc(var(--input-px) + var(--input-slide)) !important",
          borderBottomColor:
            "var(--input-color, var(--color-primary)) !important",
          boxShadow: "none !important",
        },
      },
    // For border variant, icons are clean and transparent
    ".input-wrap.input-border .input-icon-left, .input-wrap.input-border .input-icon-right, .input-box:has(.input-border) > .input-icon-left, .input-box:has(.input-border) > .input-icon-right":
      {
        backgroundColor: "transparent !important",
        boxShadow: "none !important",
      },

    // Also support alias .input-underline
    ":is(input, textarea, select).input-underline, .input-wrap.input-underline :is(input, textarea, select), .input-box:has(.input-underline) > :is(input, textarea, select)":
      {
        "--input-px": "4px",
        "--input-slide": "4px",
        backgroundColor: "transparent !important",
        borderRadius: "0px !important",
        border: "none !important",
        borderBottom:
          "2px solid color-mix(in oklab, var(--color-base-content) 20%, transparent) !important",
        paddingInlineStart: "var(--input-px)",
        "&:hover": {
          borderBottomColor: "var(--color-neutral) !important",
        },
        "&:focus, &:focus-visible": {
          backgroundColor: "transparent !important",
          paddingInlineStart:
            "calc(var(--input-px) + var(--input-slide)) !important",
          borderBottomColor:
            "var(--input-color, var(--color-primary)) !important",
          boxShadow: "none !important",
        },
      },

    // ==========================================
    // 3. Shadow Variant (.input-shadow)
    // Tactile press-down and rich ambient glow
    // ==========================================
    ".input-shadow": {
      backgroundColor: "var(--color-base-500)",
      border: "2px solid transparent !important",
      borderRadius: "var(--radius-input, 12px)",
      boxShadow:
        "0px 6px 20px -6px color-mix(in oklab, var(--input-color, var(--color-primary)) 40%, rgba(var(--shadow-color), 0.3))",
      "&:hover": {
        backgroundColor:
          "color-mix(in oklab, var(--color-base-500) 80%, var(--color-base-content))",
        boxShadow:
          "0px 8px 24px -5px color-mix(in oklab, var(--input-color, var(--color-primary)) 50%, rgba(var(--shadow-color), 0.35))",
      },
      "&:focus, &:focus-visible": {
        transform: "translateY(2px)", // tactile sink on focus!
        backgroundColor:
          "color-mix(in oklab, var(--color-base-500) 88%, var(--color-base))",
        borderBottom: "2px solid transparent !important",
        boxShadow:
          "0px 2px 8px -2px color-mix(in oklab, var(--input-color, var(--color-primary)) 55%, rgba(var(--shadow-color), 0.2))",
      },
    },

    // ==========================================
    // 4. Floating Label Placeholder
    // ==========================================
    ".input-wrap.has-float-label, .input-wrap:has(.input-label-placeholder)": {
      marginTop: "1.5rem",
    },
    ".input-label-placeholder": {
      position: "absolute",
      insetInlineStart: "var(--input-px, 16px)",
      top: "50%",
      transform: "translateY(-50%)",
      fontSize: "0.85rem",
      color: "var(--color-neutral)",
      pointerEvents: "none",
      transition: "all 0.25s cubic-bezier(0.4, 0, 0.2, 1)",
      userSelect: "none",
      opacity: "0.8",
      transformOrigin: "left top",
      zIndex: "3",
    },
    "[dir='rtl'] .input-label-placeholder": {
      transformOrigin: "right top",
    },
    ".input-box:has(.input-icon-left) > .input-label-placeholder, .input-wrap:has(.input-icon-left) .input-label-placeholder":
      {
        insetInlineStart: "44px !important",
      },
    ".input-box:has(.input-icon-left).input-xs > .input-label-placeholder, .input-box:has(.input-icon-left):has(.input-xs) > .input-label-placeholder":
      {
        insetInlineStart: "38px !important",
      },
    ".input-box:has(.input-icon-left).input-sm > .input-label-placeholder, .input-box:has(.input-icon-left):has(.input-sm) > .input-label-placeholder":
      {
        insetInlineStart: "40px !important",
      },
    ".input-box:has(.input-icon-left).input-lg > .input-label-placeholder, .input-box:has(.input-icon-left):has(.input-lg) > .input-label-placeholder":
      {
        insetInlineStart: "46px !important",
      },
    ".input-box:has(.input-icon-left).input-xl > .input-label-placeholder, .input-box:has(.input-icon-left):has(.input-xl) > .input-label-placeholder":
      {
        insetInlineStart: "48px !important",
      },
    // When input focused or has text or is autofilled: float completely above and outside the box!
    ".input-box:focus-within > .input-label-placeholder": {
      transform: "translateY(-2.2rem) scale(0.85)",
      color: "var(--input-color, var(--color-primary))",
      fontWeight: "500",
      opacity: "1",
    },
    ".input-box > :is(.input, .input-border, .input-shadow):not(:placeholder-shown) ~ .input-label-placeholder, .input-box > :is(.input, .input-border, .input-shadow):-webkit-autofill ~ .input-label-placeholder":
      {
        transform: "translateY(-2.2rem) scale(0.85)",
        color: "var(--color-neutral)",
        fontWeight: "500",
        opacity: "1",
      },

    // ==========================================
    // 5. Messages
    // ==========================================
    ".input-message": {
      fontSize: "0.72rem",
      lineHeight: "1rem",
      padding: "2px 7px",
      marginTop: "4px",
      transition: "all 0.25s ease",
      overflow: "hidden",
      fontWeight: "500",
    },
    ".input-message-success": {
      color: "var(--color-success)",
    },
    ".input-message-danger": {
      color: "var(--color-danger)",
    },
    ".input-message-warn": {
      color: "var(--color-warn)",
    },
    ".input-message-primary": {
      color: "var(--color-primary)",
    },

    // ==========================================
    // 6. Transparent Variant
    // ==========================================
    ":is(input, textarea, select).input-transparent, .input-wrap.input-transparent :is(input, textarea, select), .input-box:has(.input-transparent) > :is(input, textarea, select)":
      {
        backgroundColor: "transparent !important",
        border: "2px solid transparent !important",
        boxShadow: "none !important",
        "&:hover": {
          backgroundColor: "transparent !important",
        },
        "&:focus, &:focus-visible": {
          backgroundColor: "transparent !important",
          boxShadow: "none !important",
        },
      },
    ".input-wrap.input-transparent .input-icon-left, .input-wrap.input-transparent .input-icon-right, .input-box:has(.input-transparent) > .input-icon-left, .input-box:has(.input-transparent) > .input-icon-right":
      {
        backgroundColor: "transparent !important",
        boxShadow: "none !important",
      },

    // ==========================================
    // 7. Shape Variants: Pill & Square
    // ==========================================
    ":is(.input, .input-border, .input-shadow, .input-underline).input-pill, .input-wrap.input-pill :is(.input, .input-border, .input-shadow, .input-underline), .input-box:has(.input-pill) > :is(.input, .input-border, .input-shadow, .input-underline), .input-box.input-pill":
      {
        borderRadius: "9999px !important",
        paddingInlineStart: "var(--input-px, 16px)",
        paddingInlineEnd: "var(--input-px, 16px)",
      },
    ".input-box:has(.input-pill)::after, .input-box.input-pill::after": {
      borderRadius: "9999px !important",
    },
    ":is(.input, .input-border, .input-shadow, .input-underline).input-square, .input-wrap.input-square :is(.input, .input-border, .input-shadow, .input-underline), .input-box:has(.input-square) > :is(.input, .input-border, .input-shadow, .input-underline), .input-box.input-square":
      {
        borderRadius: "0px !important",
      },
    ".input-box:has(.input-square)::after, .input-box.input-square::after": {
      borderRadius: "0px !important",
    },

    // ==========================================
    // 8. Loading State
    // ==========================================
    ".input-loading": {
      position: "absolute",
      insetInlineEnd: "10px",
      top: "50%",
      transform: "translateY(-50%)",
      width: "22px",
      height: "22px",
      pointerEvents: "none",
      boxSizing: "border-box",
      borderRadius: "50%",
      zIndex: "3",
      "&::after": {
        content: "''",
        position: "absolute",
        inset: "0px",
        borderRadius: "50%",
        border: "2px solid var(--input-color, var(--color-primary))",
        borderTopColor: "transparent !important",
        borderLeftColor: "transparent !important",
        animation: "rotateInputLoading 0.8s ease infinite",
        boxSizing: "border-box",
      },
      "&::before": {
        content: "''",
        position: "absolute",
        inset: "0px",
        borderRadius: "50%",
        border: "2px dashed var(--input-color, var(--color-primary))",
        borderTopColor: "transparent !important",
        borderLeftColor: "transparent !important",
        opacity: "0.25",
        animation: "rotateInputLoading 0.8s linear infinite",
        boxSizing: "border-box",
      },
    },
    ".input-box:has(.input-loading) > :is(.input, .input-border, .input-shadow, .input-underline), .input-wrap:has(.input-loading) :is(.input, .input-border, .input-shadow, .input-underline)":
      {
        paddingInlineEnd: "40px !important",
      },

    // ==========================================
    // 9. Progress Bar
    // ==========================================
    ".input-progress": {
      width: "96%",
      marginInline: "auto",
      marginTop: "4px",
      height: "3px",
      backgroundColor:
        "color-mix(in oklab, var(--color-base-content) 15%, transparent)",
      borderRadius: "9999px",
      overflow: "hidden",
      position: "relative",
    },
    ".input-progress-bar": {
      height: "100%",
      borderRadius: "9999px",
      backgroundColor: "var(--input-color, var(--color-primary))",
      transition:
        "width 0.3s cubic-bezier(0.4, 0, 0.2, 1), background-color 0.3s ease",
    },
    ".input-progress-danger .input-progress-bar, .input-progress-bar.is-danger": {
      backgroundColor: "var(--color-danger) !important",
    },
    ".input-progress-warn .input-progress-bar, .input-progress-bar.is-warn": {
      backgroundColor: "var(--color-warn) !important",
    },
    ".input-progress-success .input-progress-bar, .input-progress-bar.is-success": {
      backgroundColor: "var(--color-success) !important",
    },

    // ==========================================
    // 10. Interactive Icons & Password Toggle
    // ==========================================
    ".input-icon-click, .input-password-toggle": {
      pointerEvents: "auto !important",
      cursor: "pointer",
      "&:hover": {
        backgroundColor: "var(--color-base)",
        color: "var(--input-color, var(--color-primary))",
      },
      "&:active": {
        transform: "translate(0, -50%) scale(0.92)",
      },
    },

    // ==========================================
    // 11. Shortcut Badge / KBD Tag inside Input
    // ==========================================
    ".input-badge, .input-kbd": {
      position: "absolute",
      insetInlineEnd: "8px",
      top: "50%",
      transform: "translateY(-50%)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      padding: "2px 6px",
      fontSize: "0.7rem",
      fontWeight: "600",
      lineHeight: "1rem",
      color: "var(--color-neutral)",
      backgroundColor: "var(--color-base-500)",
      borderRadius: "6px",
      border:
        "1px solid color-mix(in oklab, var(--color-base-content) 15%, transparent)",
      pointerEvents: "none",
      userSelect: "none",
      zIndex: "2",
    },
    ".input-box:has(.input-badge) > :is(.input, .input-border, .input-shadow, .input-underline), .input-box:has(.input-kbd) > :is(.input, .input-border, .input-shadow, .input-underline)":
      {
        paddingInlineEnd: "58px !important",
      },

    // ==========================================
    // 12. Extended Sizes (xs, sm, md, lg, xl)
    // ==========================================
    // Container variables for sizes (whether on wrap, box, or input)
    ".input-wrap.input-xs, .input-box.input-xs, .input-box:has(.input-xs)": {
      "--input-px": "10px",
      "--input-slide": "4px",
    },
    ".input-wrap.input-sm, .input-box.input-sm, .input-box:has(.input-sm)": {
      "--input-px": "12px",
      "--input-slide": "4px",
    },
    ".input-wrap.input-md, .input-box.input-md, .input-box:has(.input-md)": {
      "--input-px": "16px",
      "--input-slide": "5px",
    },
    ".input-wrap.input-lg, .input-box.input-lg, .input-box:has(.input-lg)": {
      "--input-px": "20px",
      "--input-slide": "6px",
    },
    ".input-wrap.input-xl, .input-box.input-xl, .input-box:has(.input-xl)": {
      "--input-px": "24px",
      "--input-slide": "7px",
    },

    // ==========================================
    // 12. Extended Sizes (xs, sm, md, lg, xl)
    // Synchronized 1:1 with Button system padding, height, and typography!
    // ==========================================
    ":is(.input, .input-border, .input-shadow, .input-underline).input-xs, .input-wrap.input-xs :is(.input, .input-border, .input-shadow, .input-underline), .input-box.input-xs > :is(.input, .input-border, .input-shadow, .input-underline)":
      {
        "--input-px": "10px",
        "--input-slide": "4px",
        padding: "4px var(--input-px)",
        paddingInlineStart: "var(--input-px)",
        fontSize: "0.75rem",
        lineHeight: "1rem",
      },
    ":is(.input, .input-border, .input-shadow, .input-underline).input-sm, .input-wrap.input-sm :is(.input, .input-border, .input-shadow, .input-underline), .input-box.input-sm > :is(.input, .input-border, .input-shadow, .input-underline)":
      {
        "--input-px": "12px",
        "--input-slide": "4px",
        padding: "6px var(--input-px)",
        paddingInlineStart: "var(--input-px)",
        fontSize: "0.875rem",
        lineHeight: "1.25rem",
      },
    ":is(.input, .input-border, .input-shadow, .input-underline).input-md, .input-wrap.input-md :is(.input, .input-border, .input-shadow, .input-underline), .input-box.input-md > :is(.input, .input-border, .input-shadow, .input-underline)":
      {
        "--input-px": "16px",
        "--input-slide": "5px",
        padding: "8px var(--input-px)",
        paddingInlineStart: "var(--input-px)",
        fontSize: "0.875rem",
        lineHeight: "1.5rem",
      },
    ":is(.input, .input-border, .input-shadow, .input-underline).input-lg, .input-wrap.input-lg :is(.input, .input-border, .input-shadow, .input-underline), .input-box.input-lg > :is(.input, .input-border, .input-shadow, .input-underline)":
      {
        "--input-px": "20px",
        "--input-slide": "6px",
        padding: "10px var(--input-px)",
        paddingInlineStart: "var(--input-px)",
        fontSize: "1.125rem",
        lineHeight: "1.75rem",
      },
    ":is(.input, .input-border, .input-shadow, .input-underline).input-xl, .input-wrap.input-xl :is(.input, .input-border, .input-shadow, .input-underline), .input-box.input-xl > :is(.input, .input-border, .input-shadow, .input-underline)":
      {
        "--input-px": "24px",
        "--input-slide": "7px",
        padding: "12px var(--input-px)",
        paddingInlineStart: "var(--input-px)",
        fontSize: "1.25rem",
        lineHeight: "1.75rem",
      },
  });

  // ==========================================
  // Color Theme Modifiers & State Modifiers
  // ==========================================
  const colors = [
    "primary",
    "success",
    "warn",
    "danger",
    "secondary",
    "info",
    "accent",
  ];

  const variantStyles = {};

  colors.forEach((name) => {
    const col = `var(--color-${name})`;

    // Color token binding for BOTH color variants AND state variants on all wrappers & boxes
    variantStyles[
      `.input-${name}, .input-wrap.input-${name}, .input-box:has(.input-${name}), .input-state-${name}, .input-wrap.input-state-${name}, .input-box:has(.input-state-${name})`
    ] = {
      "--input-color": col,
    };

    // States: .input-state-success, .input-state-danger, .input-state-warn
    variantStyles[
      `.input.input-state-${name}, .input-wrap.input-state-${name} :is(.input, .input-border, .input-shadow, .input-underline)`
    ] = {
      "--input-color": col,
      backgroundColor: `color-mix(in oklab, ${col} 10%, var(--color-base-500)) !important`,
      color: `${col} !important`,
      border: "2px solid transparent !important",
      borderBottom: "2px solid transparent !important",
      "&::placeholder": {
        color: col,
        opacity: "0.7",
      },
    };

    variantStyles[
      `.input-wrap.input-state-${name} .input-icon-left, .input-wrap.input-state-${name} .input-icon-right`
    ] = {
      color: `${col} !important`,
      backgroundColor: `color-mix(in oklab, ${col} 14%, var(--color-base-500)) !important`,
      boxShadow: "none !important",
    };

    variantStyles[`.input-wrap.input-state-${name} > .input-label`] = {
      color: `${col} !important`,
    };
  });

  addComponents(variantStyles);
}
