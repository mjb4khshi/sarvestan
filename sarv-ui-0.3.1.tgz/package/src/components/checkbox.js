// 🌿 Sarv UI v0.3.0
// Built with care by MJ
export default function checkbox({
  addComponents,
  addUtilities,
  matchUtilities,
  theme,
  matchComponents,
}) {
  addComponents({
    ".checkbox": {
      "@apply inline-flex relative items-center justify-center rounded-checkbox cursor-pointer size-5 select-none":
        {},
      width: "var(--cb-size, theme(spacing.5))",
      height: "var(--cb-size, theme(spacing.5))",
      transition:
        "box-shadow 0.25s ease, background-color 0.25s ease, transform 0.25s ease, opacity 0.25s ease",
    },
    ".checkbox input": {
      "@apply absolute inset-0 m-0 appearance-none cursor-pointer opacity-0 z-10 w-full h-full":
        {},
    },
    ".checkbox::after": {
      content: '""',
      "@apply absolute inset-0 bg-current z-1 rounded-[inherit] opacity-0 pointer-events-none":
        {},
      boxShadow: "0 0 0 0px currentColor",
      transform: "scale(0.8)",
      transition:
        "transform 0.25s ease, opacity 0.25s ease, box-shadow 0.25s ease",
    },
    ".checkbox:not(:has(input:checked))": {
      boxShadow: "inset 0 0 0 2px var(--color-base-500)",
    },
    ".checkbox:not(:has(input:checked)):hover": {
      "@apply bg-base-500": {},
      boxShadow: "inset 0 0 0 var(--color-base-500)",
    },
    ".checkbox:has(input:focus-visible)": {
      outline: "none",
      boxShadow:
        "inset 0 0 0 2px var(--color-base-500), 0 0 0 3px color-mix(in oklab, currentColor 40%, transparent)",
    },
    ".checkbox:has(input:checked)": {
      "@apply bg-base-500": {},
    },
    ".checkbox:has(input:checked:focus-visible)": {
      boxShadow: "0 0 0 3px color-mix(in oklab, currentColor 45%, transparent)",
    },
    ".checkbox:has(input:checked)::after": {
      "@apply opacity-[1] delay-0": {},
      transform: "scale(1)",
      boxShadow: "0 0 0px currentColor",
    },
    ".checkbox:has(input:checked):hover::after": {
      "@apply opacity-[1] delay-0": {},
      transform: "scale(1)",
      boxShadow: "0 0 2px currentColor",
    },
    ".checkbox-icon": {
      "@apply absolute z-2 w-4/5 h-4/5 pointer-events-none": {},
    },
    ".checkbox-icon path, .checkbox-icon line, .checkbox-icon polyline": {
      "@apply stroke-2 fill-none cb-animate": {},
    },
    ".checkbox:has(input:checked) .checkbox-icon path, .checkbox:has(input:checked) .checkbox-icon line, .checkbox:has(input:checked) .checkbox-icon polyline":
      {
        "@apply delay-200": {},
        strokeDashoffset: 0,
      },
    ".checkbox:not(:has(input:checked)) .checkbox-icon path, .checkbox:not(:has(input:checked)) .checkbox-icon line, .checkbox:not(:has(input:checked)) .checkbox-icon polyline":
      {
        "@apply delay-0": {},
        strokeDashoffset: 200,
      },
    ".checkbox:has(input:disabled)": {
      "@apply cursor-not-allowed opacity-50": {},
    },
    ".checkbox:has(input:checked:disabled)": {
      "@apply cursor-not-allowed text-neutral": {},
    },
  });
  addUtilities({
    ".cb-animate": {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      strokeDasharray: "200",
      strokeDashoffset: "200",
      transition: "stroke-dashoffset 1.1s ease-in-out",
    },
  });
  matchUtilities(
    {
      checkbox: (value) => ({
        "--cb-size": value,
      }),
    },
    {
      values: {
        xs: theme("spacing.3"),
        sm: theme("spacing.4"),
        md: theme("spacing.5"),
        lg: theme("spacing.6"),
        xl: theme("spacing.7"),
        "2xl": theme("spacing.8"),
        "3xl": theme("spacing.9"),
        "4xl": theme("spacing.10"),
      },
    }
  );

  addComponents({
    ".checkbox-mask": {
      width: "var(--cb-size, theme(spacing.5))",
      height: "var(--cb-size, theme(spacing.5))",
    },
  });
  matchComponents(
    {
      checkbox: (value) => ({
        color: theme(`colors.${value}.DEFAULT`),
        stroke: theme(`colors.${value}.content`),
      }),
    },
    {
      values: {
        primary: "primary",
        success: "success",
        warn: "warn",
        info: "info",
        secondary: "secondary",
        danger: "danger",
        accent: "accent",
      },
    }
  );
}
