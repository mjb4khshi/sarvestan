// 🌿 Sarv UI v0.3.0
// Built with care by MJ
export default function badges({ addComponents, matchComponents, theme }) {
  addComponents({
    ".badge": {
      display: "inline-flex",
      alignItems: "center",
      fontWeight: "500",
      fontSize: "0.75rem",
      lineHeight: "1rem",
      padding: "2px 8px",
      borderRadius: "var(--radius-badge, 9999px)",
      transition: "background-color 0.2s ease, color 0.2s ease, border-radius 0.2s ease",
    },
    "[datatheme*='sharp'] .badge": {
      borderRadius: "0px !important",
    },
  });

  matchComponents(
    {
      badge: (value) => ({
        backgroundColor: theme(`colors.${value}.DEFAULT`),
        color: theme(`colors.${value}.content`),
      }),
    },
    {
      values: {
        primary: "primary",
        success: "success",
        warn: "warn",
        danger: "danger",
        secondary: "secondary",
        info: "info",
        accent: "accent",
        neutral: "neutral",
      },
    }
  );

  matchComponents(
    {
      "badge-soft": (value) => ({
        backgroundColor: theme(`colors.${value}[300]`),
        color: theme(`colors.${value}.DEFAULT`),
      }),
    },
    {
      values: {
        primary: "primary",
        success: "success",
        warn: "warn",
        danger: "danger",
        secondary: "secondary",
        info: "info",
        accent: "accent",
        neutral: "neutral",
      },
    }
  );

  matchComponents(
    {
      "badge-outline": (value) => ({
        border: `1px solid ${theme(`colors.${value}.DEFAULT`)}`,
        color: theme(`colors.${value}.DEFAULT`),
        backgroundColor: "transparent",
      }),
    },
    {
      values: {
        primary: "primary",
        success: "success",
        warn: "warn",
        danger: "danger",
        secondary: "secondary",
        info: "info",
        accent: "accent",
        neutral: "neutral",
      },
    }
  );
}
