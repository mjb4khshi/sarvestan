// 🌿 Sarv UI v0.3.0
// Built with care by MJ

export default function button({ addComponents, matchComponents, theme }) {
  addComponents({
    ".btn": {
      "@apply flex cursor-pointer gap-0 items-center justify-center rounded-button font-medium transition-all duration-200 outline-none":
        {},
      padding: `${theme("spacing.2")} ${theme("spacing.4")}`,
      "&:hover": { transform: "scale(1.02)" },
      "&:active": { transform: "scale(0.98)" },
      "&:focus-visible": {
        outline: "none",
        boxShadow: "0 0 0 3px color-mix(in oklab, currentColor 40%, transparent)",
      },
    },
  });

  matchComponents(
    {
      btn: (value) => ({
        backgroundColor: theme(`colors.${value}.DEFAULT`),
        color: theme(`colors.${value}.content`),
      }),
    },
    {
      values: {
        primary: "primary",
        success: "success",
        warn: "warn",
        danger: "danger",
        secondary: "secondary",
        info: "info",
        accent: "accent",
        neutral: "neutral",
      },
    }
  );

  matchComponents(
    {
      "btn-soft": (value) => ({
        backgroundColor: theme(`colors.${value}[300]`),
        color: theme(`colors.${value}.DEFAULT`),
        "&:hover": {
          backgroundColor: theme(`colors.${value}.DEFAULT`),
          color: theme(`colors.${value}.content`),
        },
      }),
    },
    {
      values: {
        primary: "primary",
        success: "success",
        warn: "warn",
        danger: "danger",
        secondary: "secondary",
        info: "info",
        accent: "accent",
        neutral: "neutral",
      },
    }
  );

  matchComponents(
    {
      "btn-outline": (value) => ({
        border: `2px solid ${theme(`colors.${value}.DEFAULT`)}`,
        color: theme(`colors.${value}.DEFAULT`),
        backgroundColor: "transparent",
        "&:hover": {
          backgroundColor: theme(`colors.${value}.DEFAULT`),
          color: theme(`colors.${value}.content`),
        },
      }),
    },
    {
      values: {
        primary: "primary",
        success: "success",
        warn: "warn",
        danger: "danger",
        secondary: "secondary",
        info: "info",
        accent: "accent",
        neutral: "neutral",
      },
    }
  );

  matchComponents(
    {
      "btn-shadow": (value) => ({
        backgroundColor: theme(`colors.${value}.DEFAULT`),
        color: theme(`colors.${value}.content`),
        boxShadow: `0 8px 16px -4px color-mix(in oklab, ${theme(`colors.${value}.DEFAULT`)} 50%, transparent)`,
        "&:hover": {
          transform: "translateY(-3px) scale(1.02)",
          boxShadow: `0 14px 24px -4px color-mix(in oklab, ${theme(`colors.${value}.DEFAULT`)} 65%, transparent)`,
        },
        "&:active": {
          transform: "translateY(0) scale(0.98)",
          boxShadow: `0 4px 8px -2px color-mix(in oklab, ${theme(`colors.${value}.DEFAULT`)} 40%, transparent)`,
        },
      }),
    },
    {
      values: {
        primary: "primary",
        success: "success",
        warn: "warn",
        danger: "danger",
        secondary: "secondary",
        info: "info",
        accent: "accent",
        neutral: "neutral",
      },
    }
  );

  matchComponents(
    {
      "btn-relief": (value) => ({
        backgroundColor: theme(`colors.${value}.DEFAULT`),
        color: theme(`colors.${value}.content`),
        boxShadow: `0 4px 0 0 color-mix(in oklab, ${theme(`colors.${value}.DEFAULT`)} 70%, black)`,
        "&:hover": {
          transform: "translateY(-1px)",
          boxShadow: `0 5px 0 0 color-mix(in oklab, ${theme(`colors.${value}.DEFAULT`)} 70%, black)`,
        },
        "&:active": {
          transform: "translateY(4px)",
          boxShadow: "0 0 0 0 transparent",
        },
      }),
    },
    {
      values: {
        primary: "primary",
        success: "success",
        warn: "warn",
        danger: "danger",
        secondary: "secondary",
        info: "info",
        accent: "accent",
        neutral: "neutral",
      },
    }
  );

  matchComponents(
    {
      btn: (value) => ({
        fontSize: theme(`fontSize.${value}`)[0],
        lineHeight: theme(`fontSize.${value}`)[1].lineHeight,
        padding:
          value === "xs"
            ? `${theme("spacing.1")} ${theme("spacing.2")}`
            : value === "sm"
            ? `${theme("spacing.1.5")} ${theme("spacing.3")}`
            : value === "md"
            ? `${theme("spacing.2")} ${theme("spacing.4")}`
            : value === "lg"
            ? `${theme("spacing.2.5")} ${theme("spacing.5")}`
            : `${theme("spacing.3")} ${theme("spacing.6")}`,
      }),
    },
    {
      values: {
        xs: "xs",
        sm: "sm",
        md: "base",
        lg: "lg",
        xl: "xl",
      },
    }
  );
}
