// 🌿 Sarv UI - Animated Custom Select & Dropdown Component
// Built with care by MJ

export default function select({ addComponents }) {


  addComponents({
    // Wrapper for select
    ".select-wrap": {
      display: "inline-flex",
      flexDirection: "column",
      position: "relative",
      color: "var(--color-base-content)",
      "&.select-block, &.w-full": {
        width: "100%",
      },
    },

    // Label for select
    ".select-label": {
      display: "block",
      fontSize: "0.8rem",
      lineHeight: "1.15rem",
      fontWeight: "500",
      color: "var(--color-neutral)",
      marginBottom: "0.35rem",
      transition: "color 0.25s ease",
      userSelect: "none",
      ".select-wrap:focus-within > &, .select-wrap:has(.is-open) > &": {
        color: "var(--select-color, var(--color-primary))",
      },
    },

    // ==========================================
    // Custom Select Component (.select)
    // Works via .select container with .select-trigger + .select-menu
    // Powered 100% by system design tokens
    // ==========================================
    ".select": {
      position: "relative",
      display: "inline-block",
      width: "100%",
      userSelect: "none",

      // Trigger box (looks identical to input with smooth animated chevron)
      "& > .select-trigger": {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        width: "100%",
        boxSizing: "border-box",
        "--select-px": "16px",
        "--select-slide": "4px",
        padding: "8px var(--select-px)",
        paddingInlineStart: "var(--select-px)",
        fontSize: "0.875rem",
        lineHeight: "1.5rem",
        borderRadius: "var(--radius-input, 12px)",
        backgroundColor: "var(--color-base-500)",
        color: "var(--color-base-content)",
        border: "2px solid transparent",
        cursor: "pointer",
        outline: "none",
        transition: "all 0.25s cubic-bezier(0.4, 0, 0.2, 1)",

        "&:hover": {
          backgroundColor:
            "color-mix(in oklab, var(--color-base-500) 80%, var(--color-base-content))",
        },

        "&:focus, &:focus-visible": {
          backgroundColor:
            "color-mix(in oklab, var(--color-base-500) 88%, var(--color-base))",
          paddingInlineStart:
            "calc(var(--select-px) + var(--select-slide)) !important",
          borderBottomColor:
            "var(--select-color, var(--color-primary)) !important",
        },

        "& > .select-value": {
          display: "flex",
          alignItems: "center",
          gap: "8px",
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap",
        },

        "& > .select-chevron": {
          width: "16px",
          height: "16px",
          transition:
            "transform 0.25s cubic-bezier(0.4, 0, 0.2, 1), color 0.25s ease",
          color: "var(--color-neutral)",
          strokeWidth: "2.2",
          flexShrink: "0",
          marginInlineStart: "8px",
        },
      },

      // Open State: Chevron flips, trigger highlights and bottom line appears
      "&.is-open > .select-trigger": {
        backgroundColor:
          "color-mix(in oklab, var(--color-base-500) 88%, var(--color-base))",
        borderBottomColor:
          "var(--select-color, var(--color-primary)) !important",
        "& > .select-chevron": {
          transform: "rotate(180deg)",
          color: "var(--select-color, var(--color-primary))",
        },
      },

      // Floating Options Menu (.select-menu)
      "& > .select-menu": {
        position: "absolute",
        top: "calc(100% + 6px)",
        insetInlineStart: "0px",
        width: "100%",
        minWidth: "160px",
        maxHeight: "260px",
        overflowY: "auto",
        backgroundColor:
          "color-mix(in oklab, var(--color-base-500) 80%, var(--color-base))",
        borderRadius: "var(--radius-input, 12px)",
        border:
          "1px solid color-mix(in oklab, var(--color-base-content) 15%, transparent)",
        padding: "6px",
        zIndex: "50",
        opacity: "0",
        visibility: "hidden",
        transform: "translateY(-8px) scale(0.97)",
        transformOrigin: "top center",
        transition: "all 0.22s cubic-bezier(0.4, 0, 0.2, 1)",
        boxShadow:
          "0px 14px 28px -6px rgba(var(--shadow-color), 0.35), 0px 4px 10px -2px rgba(var(--shadow-color), 0.15)",
        // Sleek scrollbar
        "&::-webkit-scrollbar": {
          width: "5px",
        },
        "&::-webkit-scrollbar-thumb": {
          backgroundColor:
            "color-mix(in oklab, var(--color-base-content) 20%, transparent)",
          borderRadius: "9999px",
        },
      },

      // Open state with smooth pop-in animation
      "&.is-open > .select-menu": {
        opacity: "1",
        visibility: "visible",
        transform: "translateY(0px) scale(1)",
      },

      // Individual Option (.select-option)
      "& .select-option": {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: "8px",
        padding: "8px 12px",
        borderRadius: "calc(var(--radius-input, 12px) - 4px)",
        fontSize: "0.85rem",
        color: "var(--color-base-content)",
        cursor: "pointer",
        transition: "all 0.18s ease",
        outline: "none",
        "& > span, & > .select-option-label": {
          display: "inline-flex",
          alignItems: "center",
          gap: "6px",
          transition: "transform 0.2s cubic-bezier(0.4, 0, 0.2, 1)",
        },
        "&:hover": {
          backgroundColor:
            "color-mix(in oklab, var(--select-color, var(--color-primary)) 14%, var(--color-base-500))",
          color: "var(--select-color, var(--color-primary))",
        },
        "&:hover > span, &:hover > .select-option-label": {
          transform: "translateX(5px)",
        },
        "&.is-selected": {
          backgroundColor:
            "color-mix(in oklab, var(--select-color, var(--color-primary)) 20%, var(--color-base-500))",
          color: "var(--select-color, var(--color-primary))",
          fontWeight: "600",
        },
        "& > .option-check": {
          width: "16px",
          height: "16px",
          opacity: "0",
          transform: "scale(0.6)",
          transition: "all 0.2s ease",
          color: "var(--select-color, var(--color-primary))",
          flexShrink: "0",
        },
        "&.is-selected > .option-check": {
          opacity: "1",
          transform: "scale(1)",
        },
        "&.is-disabled": {
          opacity: "0.4",
          cursor: "not-allowed",
          pointerEvents: "none",
        },
      },
    },

    // RTL for select hover slide (only text slides)
    "[dir='rtl'] .select .select-option:hover > span, [dir='rtl'] .select .select-option:hover > .select-option-label":
      {
        transform: "translateX(-5px)",
      },

    // ==========================================
    // Optional .select-box for center-expanding line on trigger
    // ==========================================
    ".select-box": {
      position: "relative",
      width: "100%",
      borderRadius: "var(--radius-input, 12px)",
      "&::after": {
        content: "''",
        position: "absolute",
        inset: "0px",
        borderRadius: "var(--radius-input, 12px)",
        border: "2px solid transparent",
        borderBottom:
          "2px solid var(--select-color, var(--color-primary)) !important",
        boxSizing: "border-box",
        pointerEvents: "none",
        clipPath: "inset(0 50% 0 50%)",
        transition: "clip-path 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
        zIndex: "4",
      },
      "&:has(.is-open)::after, &:focus-within::after": {
        clipPath: "inset(0 0% 0 0%)",
      },
      "& > .select > .select-trigger:focus, & > .select.is-open > .select-trigger":
        {
          borderBottomColor: "transparent !important",
        },
    },

    // ==========================================
    // Style Variants: Border & Shadow
    // ==========================================
    ".select.select-border > .select-trigger, .select-border > .select > .select-trigger":
      {
        backgroundColor: "transparent !important",
        borderRadius: "0px !important",
        border: "none !important",
        borderBottom:
          "2px solid color-mix(in oklab, var(--color-base-content) 20%, transparent) !important",
        paddingInlineStart: "6px",
        "--select-px": "6px",
        "--select-slide": "4px",
        "&:hover": {
          borderBottomColor: "var(--color-neutral) !important",
        },
        "&:focus, &:focus-visible": {
          backgroundColor: "transparent !important",
          paddingInlineStart: "10px !important",
          borderBottomColor:
            "var(--select-color, var(--color-primary)) !important",
        },
      },
    ".select-box:has(.select-border)::after": {
      borderRadius: "0px !important",
    },

    ".select.select-shadow > .select-trigger, .select-shadow > .select > .select-trigger":
      {
        backgroundColor: "var(--color-base-500)",
        boxShadow:
          "0px 6px 20px -6px color-mix(in oklab, var(--select-color, var(--color-primary)) 40%, rgba(var(--shadow-color), 0.35))",
        "&:hover": {
          backgroundColor:
            "color-mix(in oklab, var(--color-base-500) 80%, var(--color-base-content))",
          boxShadow:
            "0px 8px 24px -5px color-mix(in oklab, var(--select-color, var(--color-primary)) 50%, rgba(var(--shadow-color), 0.4))",
        },
        "&:focus, &:focus-visible": {
          transform: "translateY(2px)",
          boxShadow:
            "0px 2px 8px -2px color-mix(in oklab, var(--select-color, var(--color-primary)) 55%, rgba(var(--shadow-color), 0.3))",
        },
      },

    // ==========================================
    // Shape Variants: Pill & Square
    // ==========================================
    ".select.select-pill > .select-trigger, .select-pill > .select > .select-trigger": {
      borderRadius: "9999px !important",
      paddingInlineStart: "20px !important",
      paddingInlineEnd: "20px !important",
    },
    ".select-box:has(.select-pill)::after": {
      borderRadius: "9999px !important",
    },
    ".select.select-square > .select-trigger, .select.select-square > .select-menu, .select.select-square .select-option": {
      borderRadius: "0px !important",
    },
    ".select-box:has(.select-square)::after": {
      borderRadius: "0px !important",
    },

    // ==========================================
    // Sizes (xs, sm, md, lg, xl)
    // Synchronized with buttons & inputs
    // ==========================================
    ".select.select-xs > .select-trigger, .select-xs > .select > .select-trigger": {
      "--select-px": "10px",
      "--select-slide": "3px",
      padding: "4px var(--select-px)",
      paddingInlineStart: "var(--select-px)",
      fontSize: "0.75rem",
      lineHeight: "1rem",
      "& > .select-chevron": {
        width: "12px",
        height: "12px",
      },
    },
    ".select.select-sm > .select-trigger, .select-sm > .select > .select-trigger": {
      "--select-px": "12px",
      "--select-slide": "4px",
      padding: "6px var(--select-px)",
      paddingInlineStart: "var(--select-px)",
      fontSize: "0.875rem",
      lineHeight: "1.25rem",
      "& > .select-chevron": {
        width: "14px",
        height: "14px",
      },
    },
    ".select.select-md > .select-trigger, .select-md > .select > .select-trigger": {
      "--select-px": "16px",
      "--select-slide": "5px",
      padding: "8px var(--select-px)",
      paddingInlineStart: "var(--select-px)",
      fontSize: "0.875rem",
      lineHeight: "1.5rem",
      "& > .select-chevron": {
        width: "16px",
        height: "16px",
      },
    },
    ".select.select-lg > .select-trigger, .select-lg > .select > .select-trigger": {
      "--select-px": "20px",
      "--select-slide": "6px",
      padding: "10px var(--select-px)",
      paddingInlineStart: "var(--select-px)",
      fontSize: "1.125rem",
      lineHeight: "1.75rem",
      "& > .select-chevron": {
        width: "18px",
        height: "18px",
      },
    },
    ".select.select-xl > .select-trigger, .select-xl > .select > .select-trigger": {
      "--select-px": "24px",
      "--select-slide": "7px",
      padding: "12px var(--select-px)",
      paddingInlineStart: "var(--select-px)",
      fontSize: "1.25rem",
      lineHeight: "1.75rem",
      "& > .select-chevron": {
        width: "20px",
        height: "20px",
      },
    },
  });

  // Color Variants
  const colors = [
    "primary",
    "secondary",
    "accent",
    "success",
    "warn",
    "danger",
    "info",
    "neutral",
  ];

  const variantStyles = {};
  colors.forEach((name) => {
    const col = `var(--color-${name})`;
    variantStyles[
      `.select-${name}, .select-wrap.select-${name}, .select-box:has(.select-${name}), .select.select-${name}`
    ] = {
      "--select-color": col,
      "--select-arrow-color": col,
    };
  });

  addComponents(variantStyles);
}
