// 🌿 Sarv UI v0.3.1
// Designed & built with care by MJ
import plugin from "tailwindcss/plugin.js";
import checkbox from "./src/components/checkbox.js";
import button from "./src/components/button.js";
import badge from "./src/components/badge.js";
import radio from "./src/components/radio.js";
import input from "./src/components/input.js";
import select from "./src/components/select.js";

export default plugin(function (api) {
  checkbox(api);
  button(api);
  badge(api);
  radio(api);
  input(api);
  select(api);
});

export {
  checkbox,
  button,
  badge,
  radio,
  input,
  select,
};

